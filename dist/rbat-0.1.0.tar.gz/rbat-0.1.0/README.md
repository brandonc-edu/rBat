# rBat
Repo for the rBat package — behavioural quantification algorithms &amp; preprocessing methods.
